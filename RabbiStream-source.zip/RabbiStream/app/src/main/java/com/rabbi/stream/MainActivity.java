package com.rabbi.stream;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import android.net.Uri;
import android.app.DownloadManager;
import java.io.File;
import java.util.*;
import org.json.*;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {
    private WebView web;
    private PlayerView playerView;
    private ExoPlayer player;
    private LinearLayout root, toolbar, bottom, playerControls;
    private TextView status, title;
    private EditText address;
    private ArrayList<QueueItem> queue = new ArrayList<>();
    private int queueIndex = -1;
    private boolean fullscreen = false, nativePlayerVisible = false;
    private float playbackSpeed = 1.0f;
    private boolean basicBlockingEnabled = true;
    private static final String HOME = "https://xhamster.com/";

    // Lightweight host denylist only; not the uBlock Origin engine or filter syntax.
    private static final String[] BLOCKED_HOSTS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
        "popads.net", "popcash.net", "exoclick.com", "trafficjunky.net",
        "adsterra.com", "propellerads.com"
    };

    private static class QueueItem {
        String url, page, title;
        QueueItem(String u, String p, String t) { url=u; page=p; title=t; }
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject(); o.put("url",url); o.put("page",page); o.put("title",title); return o;
        }
        static QueueItem from(JSONObject o) {
            return new QueueItem(o.optString("url"),o.optString("page"),o.optString("title","Video"));
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,10,13));
        getWindow().setNavigationBarColor(Color.rgb(9,10,13));
        loadQueue();
        buildUi();
        web.loadUrl(HOME);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView button(String text, Runnable r) {
        TextView v=new TextView(this); v.setText(text); v.setTextColor(Color.WHITE);
        v.setTextSize(13); v.setGravity(Gravity.CENTER); v.setPadding(dp(9),dp(10),dp(9),dp(10));
        v.setOnClickListener(x->r.run()); return v;
    }
    private void buildUi() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9,10,13)); setContentView(root);

        toolbar=new LinearLayout(this); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8),dp(4),dp(8),dp(4));
        TextView brand=button("R  STREAM",()->showWeb());
        brand.setTextColor(0xffff4165); brand.setTextSize(16); toolbar.addView(brand);
        address=new EditText(this); address.setSingleLine(true); address.setTextColor(Color.WHITE);
        address.setHintTextColor(0xff999ba5); address.setHint("Search or enter URL"); address.setTextSize(13);
        address.setPadding(dp(8),0,dp(8),0); address.setBackgroundColor(0xff202127);
        toolbar.addView(address,new LinearLayout.LayoutParams(0,dp(42),1));
        toolbar.addView(button("GO",()->navigateAddress())); root.addView(toolbar);

        status=new TextView(this); status.setTextColor(0xffb4b5bd); status.setTextSize(11);
        status.setPadding(dp(12),dp(3),dp(12),dp(3)); status.setText("Web source · Basic host blocking");
        root.addView(status);

        web=new WebView(this); web.setBackgroundColor(Color.BLACK);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true); s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false); s.setAllowFileAccess(false);
        s.setAllowContentAccess(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new PageBridge(),"RabbiBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req) {
                String scheme=req.getUrl().getScheme();
                return !("http".equals(scheme)||"https".equals(scheme));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req) {
                String host=req.getUrl().getHost();
                if(basicBlockingEnabled && host!=null && isBlocked(host))
                    return new WebResourceResponse("text/plain","utf-8",new java.io.ByteArrayInputStream(new byte[0]));
                return super.shouldInterceptRequest(v,req);
            }
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon) {
                address.setText(url); status.setText("Loading page…");
            }
            @Override public void onPageFinished(WebView v,String url) {
                status.setText("Ready · Basic blocking "+(basicBlockingEnabled?"on":"off"));
                injectMediaDetection();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onReceivedTitle(WebView v,String t) { title.setText(t==null?"Rabbi Stream":t); }
            @Override public void onProgressChanged(WebView v,int p) { if(p==100) status.setText("Ready"); }
        });
        web.setDownloadListener((url,ua,disposition,mime,length)->downloadDirect(url,disposition,mime));
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));

        playerView=new PlayerView(this); playerView.setUseController(true);
        playerView.setBackgroundColor(Color.BLACK); playerView.setVisibility(View.GONE);
        root.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));

        playerControls=new LinearLayout(this); playerControls.setGravity(Gravity.CENTER);
        playerControls.setBackgroundColor(0xff17181e);
        playerControls.addView(button("WEB",()->showWeb()));
        playerControls.addView(button("−10s",()->seekBy(-10000)));
        playerControls.addView(button("PLAY",()->togglePlay()));
        playerControls.addView(button("+10s",()->seekBy(10000)));
        playerControls.addView(button("SPEED",()->speedMenu()));
        playerControls.addView(button("NEXT",()->playNext()));
        playerControls.addView(button("FULL",()->toggleFullscreen()));
        root.addView(playerControls);

        bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER); bottom.setBackgroundColor(0xff101116);
        bottom.addView(button("Home",()->{showWeb();web.loadUrl(HOME);}));
        bottom.addView(button("Back",()->{if(nativePlayerVisible)showWeb();else if(web.canGoBack())web.goBack();}));
        bottom.addView(button("Add queue",()->addCurrentToQueue()));
        bottom.addView(button("Queue",()->showQueue()));
        bottom.addView(button("Download",()->downloadCurrent()));
        bottom.addView(button("Ad block",()->toggleBlocking()));
        root.addView(bottom);

        title=new TextView(this); title.setText("Rabbi Stream · XHamster"); title.setTextColor(0xffaaaaaa);
        title.setTextSize(10); title.setPadding(dp(10),dp(2),dp(10),dp(2)); root.addView(title);
        address.setOnEditorActionListener((v,a,event)->{navigateAddress();return true;});
        initPlayer();
    }

    private void initPlayer() {
        player=new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if(state==Player.STATE_ENDED) playNext();
            }
            @Override public void onPlayerError(androidx.media3.common.PlaybackException e) {
                Toast.makeText(MainActivity.this,"This stream format or source is not supported.",Toast.LENGTH_LONG).show();
            }
        });
    }
    private boolean isBlocked(String host) {
        for(String d:BLOCKED_HOSTS) if(host.equals(d)||host.endsWith("."+d)) return true;
        return false;
    }
    private void navigateAddress() {
        String q=address.getText().toString().trim(); if(q.isEmpty())return;
        String u;
        if(q.startsWith("https://")||q.startsWith("http://"))u=q;
        else if(q.contains(".")&&!q.contains(" "))u="https://"+q;
        else u="https://xhamster.com/search/"+Uri.encode(q);
        showWeb(); web.loadUrl(u);
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);
    }
    private void injectMediaDetection() {
        String js="(function(){"+
          "function scan(){var v=document.querySelector('video');if(!v)return;"+
          "var u=v.currentSrc||v.src;if(u&&/^https?:/.test(u)){"+
          "var t=document.title||'Video';window.RabbiBridge.onMedia(u,location.href,t);}}"+
          "scan();new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true,attributes:true});"+
          "document.addEventListener('play',scan,true);})();";
        web.evaluateJavascript(js,null);
    }
    private class PageBridge {
        @JavascriptInterface public void onMedia(String mediaUrl,String pageUrl,String pageTitle) {
            runOnUiThread(()->{
                if(mediaUrl==null||mediaUrl.isEmpty())return;
                status.setText("HTML5 media detected · available to add to queue");
                lastDetected=new QueueItem(mediaUrl,pageUrl,pageTitle==null?"Video":pageTitle);
            });
        }
    }
    private QueueItem lastDetected;
    private void playItem(QueueItem item) {
        if(item==null||item.url==null)return;
        try {
            Uri uri=Uri.parse(item.url);
            if(!"http".equals(uri.getScheme())&&!"https".equals(uri.getScheme()))throw new Exception("scheme");
            player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play();
            nativePlayerVisible=true; web.setVisibility(View.GONE); playerView.setVisibility(View.VISIBLE);
            title.setText(item.title); status.setText("Native playback · stream URL provided by page");
        } catch(Exception e) { Toast.makeText(this,"Cannot play this media URL.",Toast.LENGTH_SHORT).show(); }
    }
    private void showWeb() {
        nativePlayerVisible=false; playerView.setVisibility(View.GONE); web.setVisibility(View.VISIBLE);
        if(fullscreen)toggleFullscreen();
    }
    private void addCurrentToQueue() {
        QueueItem item=lastDetected;
        if(item==null) {
            String u=web.getUrl(); if(u!=null)item=new QueueItem(u,u,web.getTitle()==null?"Web page":web.getTitle());
        }
        if(item==null){Toast.makeText(this,"Open a page with a playable HTML5 video first.",Toast.LENGTH_LONG).show();return;}
        queue.add(item); saveQueue();
        if(queueIndex<0)queueIndex=0;
        Toast.makeText(this,"Added to queue ("+queue.size()+")",Toast.LENGTH_SHORT).show();
    }
    private void playNext() {
        if(queue.isEmpty()){Toast.makeText(this,"Queue is empty.",Toast.LENGTH_SHORT).show();return;}
        queueIndex=(queueIndex+1)%queue.size(); playItem(queue.get(queueIndex));
    }
    private void showQueue() {
        if(queue.isEmpty()){new AlertDialog.Builder(this).setMessage("Queue is empty. Open a page with an HTML5 video and tap Add queue.").setPositiveButton("OK",null).show();return;}
        String[] items=new String[queue.size()];
        for(int i=0;i<queue.size();i++)items[i]=(i==queueIndex?"▶ ":"")+queue.get(i).title;
        new AlertDialog.Builder(this).setTitle("Play queue").setItems(items,(d,w)->{queueIndex=w;playItem(queue.get(w));})
            .setNeutralButton("Clear",(d,w)->{queue.clear();queueIndex=-1;saveQueue();})
            .setNegativeButton("Close",null).show();
    }
    private void saveQueue() {
        try {JSONArray a=new JSONArray();for(QueueItem q:queue)a.put(q.json());
            getSharedPreferences("rabbi",0).edit().putString("queue",a.toString()).apply();
        }catch(Exception ignored){}
    }
    private void loadQueue() {
        try {JSONArray a=new JSONArray(getSharedPreferences("rabbi",0).getString("queue","[]"));
            for(int i=0;i<a.length();i++)queue.add(QueueItem.from(a.getJSONObject(i)));
        }catch(Exception ignored){}
    }
    private void togglePlay() {
        if(!nativePlayerVisible) { Toast.makeText(this,"Add a detected media stream to the queue to use native controls.",Toast.LENGTH_SHORT).show(); return; }
        if(player.isPlaying())player.pause();else player.play();
    }
    private void seekBy(long ms) { if(nativePlayerVisible)player.seekTo(Math.max(0,player.getCurrentPosition()+ms)); }
    private void speedMenu() {
        String[] opts={"0.5×","0.75×","1×","1.25×","1.5×","1.75×","2×"};
        float[] vals={.5f,.75f,1f,1.25f,1.5f,1.75f,2f};
        new AlertDialog.Builder(this).setTitle("Playback speed").setItems(opts,(d,w)->{
            playbackSpeed=vals[w]; if(nativePlayerVisible)player.setPlaybackParameters(new PlaybackParameters(playbackSpeed));
            Toast.makeText(this,"Speed "+opts[w],Toast.LENGTH_SHORT).show();
        }).show();
    }
    private void toggleFullscreen() {
        fullscreen=!fullscreen;
        if(fullscreen) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            toolbar.setVisibility(View.GONE);bottom.setVisibility(View.GONE);status.setVisibility(View.GONE);title.setVisibility(View.GONE);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            toolbar.setVisibility(View.VISIBLE);bottom.setVisibility(View.VISIBLE);status.setVisibility(View.VISIBLE);title.setVisibility(View.VISIBLE);
        }
    }
    private void toggleBlocking() {
        basicBlockingEnabled=!basicBlockingEnabled;
        status.setText("Basic host blocking "+(basicBlockingEnabled?"enabled":"disabled")+" (not uBlock Origin)");
        web.reload();
    }
    private void downloadCurrent() {
        if(lastDetected==null){Toast.makeText(this,"No direct HTML5 media URL detected.",Toast.LENGTH_LONG).show();return;}
        downloadDirect(lastDetected.url,null,null);
    }
    private void downloadDirect(String url,String disposition,String mime) {
        try {
            Uri uri=Uri.parse(url);
            String path=uri.getPath()==null?"":uri.getPath().toLowerCase(Locale.ROOT);
            if(path.endsWith(".m3u8")||path.endsWith(".mpd")) {
                Toast.makeText(this,"Adaptive streaming downloads need a dedicated permitted downloader; not supported here.",Toast.LENGTH_LONG).show();return;
            }
            DownloadManager.Request req=new DownloadManager.Request(uri);
            req.setTitle("Rabbi Stream download");req.setDescription("Direct media download");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setAllowedOverMetered(true);req.setAllowedOverRoaming(false);
            String name=URLUtil.guessFileName(url,disposition,mime);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name);
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
            Toast.makeText(this,"Download queued if the source permits it.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"This source does not expose a downloadable direct media URL.",Toast.LENGTH_LONG).show();}
    }
    @Override public void onBackPressed() {
        if(fullscreen){toggleFullscreen();return;}
        if(nativePlayerVisible){showWeb();return;}
        if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(web!=null)web.destroy();
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
