# Rabbi Stream Android — prototype v0.2.0

Standalone Android Studio project. Starts at XHamster and provides a YouTube-inspired dark shell.

## Added in v0.2.0
- AndroidX Media3 ExoPlayer + HLS module.
- HTML5 `<video>` source detection through a JavaScript bridge.
- Native player view for media URLs explicitly exposed by the page.
- Persistent queue of detected media streams/page URLs.
- Queue selection and automatic advance after a native media item ends.
- Playback speed, seek, fullscreen, and direct-file DownloadManager support.
- Toggle for a small built-in host denylist.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK Platform 35 installed. Let Gradle sync, then Build > Build APK(s).
Package: `com.rabbi.stream`; min SDK 23; target SDK 35.

## Limitations — important
- This is still a prototype source project, not a verified/compiled APK.
- It does not extract protected streams, defeat DRM, bypass logins/age checks, or circumvent anti-bot measures.
- The page must expose a standard HTML5 video URL for native playback. Many sites use blob URLs, signed URLs, encrypted streams, custom players, or other mechanisms that will not work with this simple bridge.
- HLS playback depends on a supported, accessible playlist and any required headers/cookies. The prototype does not forward all browser cookies/headers into Media3.
- Queue contains detected stream URLs, but the website may rotate/expire those URLs. Play Next only works for valid queued URLs.
- Direct downloads work only for direct media files that the source permits. HLS/DASH download is not implemented.
- The host denylist is a tiny static list, NOT uBlock Origin. uBlock Origin cannot be embedded as-is into Android WebView; full extension-level filtering would need a compatible browser extension host or a separately implemented filter engine.
- Ambient mode, recommendations, subscriptions, comments, accounts, and YouTube-specific functions are not implemented.
- Use only where lawful and for content you are authorized to access or download. Add age-gating, privacy policy, and security review before distribution.


## GitHub Actions build and signing
The included `.github/workflows/android.yml` builds a debug APK on push/manual run and uploads it as a workflow artifact. It signs a release APK only when all signing secrets are configured in the GitHub repository:
- `ANDROID_KEYSTORE_BASE64` — base64-encoded JKS/PKCS12 keystore
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Do not commit the keystore or passwords. Add them under Repository Settings → Secrets and variables → Actions. If you do not already own a signing keystore, create one locally and keep a secure backup before publishing; losing it can prevent future updates under the same app identity. The workflow has not yet been run or verified.
